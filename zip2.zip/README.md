1.Add at least 3 Project features

a. Clicking on Donation will add the donation and show a toast that says "Your Donation Successful". b.A category cannot be selected more than once 