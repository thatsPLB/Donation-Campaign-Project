const ErrorPage = () => {
    return (
        <div className="h-screen flex justify-center items-center">
            404 Page Not Found
        </div>
    );
};

export default ErrorPage;