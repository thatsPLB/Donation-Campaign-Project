

const Banner = () => {
    return (
        <div className="h-[70vh] bg-green-200">
            Banner
        </div>
    );
};

export default Banner;