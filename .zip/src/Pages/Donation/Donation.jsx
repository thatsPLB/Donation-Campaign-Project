import { useEffect, useState } from "react";
import SingleCard from "../Category/SingleCard";

const Donation = () => {

    const [donate,setDonate] =  useState([])

    const[noFound, setNoFound] = useState("")
    useEffect(()=>{
        const donateItem = JSON.parse(localStorage.getItem('donation'))
        if(donateItem){
            setDonate(donateItem)
        }
        else{
            setNoFound("no data found")
        }

    },[])
    console.log(donate);
    return (
        <div>
            {noFound? <p className="h-[80vh] flex justify-center items-center">{noFound}</p> 
            :
            <div>
                
                <div className="grid grid-cols-2 gap-5">
                   {donate.map(category => <SingleCard key={category.id} category={category}></SingleCard>)} 
                </div>
                {donate.length >4 && <button onClick={} className="px-5 bg-green-600 block mx-auto">See All</button>}
                </div>}
        </div>
    );
};

export default Donation;