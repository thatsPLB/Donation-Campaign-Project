

const Statistics = () => {
    return (
        <div>
           This is Statistics 
        </div>
    );
};

export default Statistics;