const Donation = () => {
    return (
        <div>
            This is Donation
        </div>
    );
};

export default Donation;