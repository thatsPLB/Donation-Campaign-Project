

const Logo = () => {
    return (
        <div>
           <img src="/./src/assets/Logo.png" alt="" /> 
        </div>
    );
};

export default Logo;