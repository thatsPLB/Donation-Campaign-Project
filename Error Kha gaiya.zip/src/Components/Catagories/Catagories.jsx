const Catagories = ({catagories}) => {
    console.log(catagories);
    return (
        <div className="py-10" >
           <h1 className="text-2xl text-center">All catagories</h1>
           <div>
            {
                catagories?.map(category => console.log(category))
            }
           </div>
        </div>
    );
};

export default Catagories;